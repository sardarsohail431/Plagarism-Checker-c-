
#pragma once
#include<iostream>
#include<fstream>   // for file handeling
#include<cmath>		// for using square and square root functions
#include<cstring>	// for using string functions ,
#include<string.h>	//	like strcpy_s() , strcmp_s() , strcar_s()

using namespace std;

struct vector  // a struct to store  words and their frequency 
{
	char word[15];
	int count;
};

class read  // a class to take input from files.
{
public:

	char *get;
	ifstream fin;

	read(char *fname);

	void gotostart();

	int totalwords();

};


class comparison  // a class to comparison between two files.
{
	read file1;   // upper class of read as member
	read file2;

	vector *vfile1;
	vector *vfile2;

	int count;  // to have count of the no. of distinct words in both files

public:

	comparison(char *filename1, char *  filename2);

	bool exceptions(char *word);

	void result_calculate();

	void print_result(double f1, double f1_f2);

	void pre_comparison();

	void show_vector();

	void start_comparison();

	void total_comparison();

	~comparison();

};
