#include"readEcomparison.h"
#include <iostream>
using namespace std;
int main()
{
	{
		// to save names of files given by user
		char *file1 = new char;
		char *file2 = new char;

		bool firstentry = true;

		//to allow user to select multiple options with 0,1,2,3
		int n;

		while (1)  // to keep the flow of program, menu oriented 
		{

			system("cls");

			cout << "----------------------------------Plagiarism Checker-------------------------------";
			cout << "\n\n                                  Main Menu          ";

			if (firstentry) // to take names of file at the start of program
			{

				while (1)
				{
					cout << "\n\nEnter names of two  files in present directory\n (without extension)" << endl << endl;

					cin >> file1;
					cin >> file2;

					//to add extension to file names given by user using concatination function 
					strcat_s(file1, 14, ".txt");
					strcat_s(file2, 14, ".txt");

					//to check wheather the filenames are invalid or valid.
					ifstream check1, check2;

					check1.open(file1);
					check2.open(file2);


					if (check1.is_open() && check2.is_open())
					{
						cout << "\n\nFiles opened successfully\n\n";

						check1.close();
						check2.close();

						system("pause");

						break;
					}
					else
					{
						cout << "\n\nError in opening files\n\nTry again";
					}
				}

				firstentry = false;

				continue;
			}

			cout << "\n1. Re Enter names of files";
			cout << "\n2. Check Plagiarism";
			cout << "\n3. Credits";
			cout << "\n0. Exit";
			cout << "\n? ";

			cin >> n;

			if (n == 0)
			{
				return 0;
			}

			if (n == 1)
			{

				while (1)
				{
					cout << "\n\nenter names of two  files in present directory\n (without extension)" << endl << endl;

					cin >> file1;
					cin >> file2;

					strcat_s(file1, 14, ".txt");
					strcat_s(file2, 14, ".txt");

					ifstream check1, check2;

					check1.open(file1);
					check2.open(file2);


					if (check1.is_open() && check2.is_open())
					{
						cout << "\n\nFiles opened successfully\n\n";

						check1.close();
						check2.close();

						break;
					}
					else
					{
						cout << "\n\nError in opening files\n\nTry again\n\n";
					}
				}
			}

			if (n == 2)
			{
				int k;  //variable to switch between the files

				cout << "\n With respect to ";
				cout << "\n 1. file1";
				cout << "\n 2. file2\n";
				cout << " ? ";

				cin >> k;

				if (k == 1)
				{

					comparison A(file1, file2);
					A.total_comparison();


				}

				if (k == 2)
				{
					comparison A(file2, file1);
					A.total_comparison();

				}
			}

			if (n == 3)
			{
				system("cls");

				cout << "\n\n\n\n       Created by:";
				cout << "\n\n   Name: Sohail Fida ";
				cout << "\n   Rollno: L1F16BSCS0063";
				cout << "\n   Section: A\n\n";
			}


			if (n < 0 && n > 3)
			{

				cout << "\n\n  WRONG INPUT\n";

			}

			cout << endl;

			system("pause");
		}

	}
}