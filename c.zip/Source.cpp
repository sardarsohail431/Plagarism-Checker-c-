#include "readEcomparison.h"// includung header file.

using namespace std;

read::read(char *fname)		//constructor
{
	get = new char;		// initialization

	fin.open(fname);		// to open file

}

void read::gotostart()	// to go to the start of file
{
	fin.clear();
	fin.seekg(0, ios::beg);

	return;
}

int read::totalwords() // to count the total words of file
{
	gotostart();

	int totalwords = 0;

	while (fin >> get)
	{
		totalwords++;
	}

	gotostart();

	return totalwords;
}

comparison::comparison(char * filename1, char * filename2) :file1(filename1), file2(filename2)
// constructor of comparison which further calls the two constructors of class read varaibles.
{


}

bool comparison::exceptions(char *word) // to avoid common words of files during calculation of similarity
{

	char A[50][10] = { "I", "is", "am", "the", "a", "are", "you", "he", "the", "it",
		"they", "and", "an", "his", "her", "your", "we", "that", "their", "there",
		"this", "no", "not", "shall", "yes", "our", "were", "why", "where", "whose",
		"who", "how", "when", "did", "can", "my", "could", "whould", "which", "might",
		"whom", "do", "have", ".", "," };

	for (int n = 0; n < 50; n++)
	{
		if (word == A[n])
		{
			return false;
		}
	}
	return true;

}

void comparison::pre_comparison() // to	calculate distinct words from both files 
//and then copy it to vector struct of both files
{

	vector *all = new vector[file1.totalwords() + file2.totalwords()]; //a vector struct to store only distinct words

	char x[15];

	file1.fin >> x;	//taking input from file 

	strcpy_s(all[0].word, x); // function that copy two "char"s  

	bool check = true;
	int z = 1;

	while (file1.fin >> x)
	{
		for (int q = 0; q < z + 1; q++)
		{
			if (!strcmp(all[q].word, x))  // function that compares two "char"s
			{
				check = false;
			}
		}

		if (check)
		{
			strcpy_s(all[z++].word, x);
		}

		check = true;
	}

	while (file2.fin >> x)
	{
		for (int q = 0; q < z + 1; q++)
		{
			if (!strcmp(all[q].word, x))
			{
				check = false;
			}
		}

		if (check)
		{
			strcpy_s(all[z++].word, x);
		}

		check = true;
	}

	count = z; // total no. non  similiar words

	//initializing the two vectors of comparison class to the size of "count"
	vfile1 = new vector[count];
	vfile2 = new vector[count];

	for (int i = 0; i < count; i++)
	{
		strcpy_s(vfile1[i].word, all[i].word);
		strcpy_s(vfile2[i].word, all[i].word);

		vfile1[i].count = 0;
		vfile2[i].count = 0;

	}

	delete[]all; // deleting vector 
}


void comparison::start_comparison() // this function saves the frequency of  vector.word
// in vector.count
{

	file1.gotostart();

	char abc[15];

	while (file1.fin >> abc)
	{
		for (int x = 0; x < count; x++)
		{
			if (!strcmp(vfile1[x].word, abc))
			{
				vfile1[x].count++;

				break;
			}
		}
	}

	file2.gotostart();

	while (file2.fin >> abc)
	{

		for (int x = 0; x < count; x++)
		{
			if (!strcmp(vfile2[x].word, abc))
			{
				vfile2[x].count++;

				break;
			}
		}
	}

	//show_vector();

}

void comparison::show_vector() // to show the words and their frequency of both vectors
{
	system("cls");

	cout << "\n File 1 \n";

	for (int k = 0; k < count; k++)
	{
		cout << vfile1[k].word << "=" << vfile1[k].count << "  ";
	}

	cout << "\n File 2 \n";

	for (int k = 0; k < count; k++)
	{
		cout << vfile2[k].word << "=" << vfile2[k].count << "  ";
	}
	cout << endl;

}

void comparison::result_calculate() // to calculate result of the basis of words
// matched in corresponding vectors
{
	double f1_self = 0;

	double f1_f2 = 0;

	for (int k = 0; k < count; k++)
	{
		f1_self = f1_self + pow(vfile1[k].count * vfile1[k].count, 2);

		f1_f2 = f1_f2 + pow(vfile2[k].count * vfile2[k].count, 2); // taking norm   sqroot(a*a + b*b + c*c + ... )

	}

	f1_self = sqrt(f1_self);

	f1_f2 = sqrt(f1_f2);

	print_result(f1_self, f1_f2);

}

void comparison::print_result(double f1, double f1_f2) // to print the result calculated
{
	double result;

	result = f1_f2 / f1 * 100;

	cout << "\n\nThe Similarity between two files = " << f1_f2 << endl;

	if (result > 100)
	{

		result = 100;
	}

	cout << "The plagerisum = " << result << "%" << endl;


}

void comparison::total_comparison() // major function that calls other functions in order 
{

	pre_comparison();
	start_comparison();
	result_calculate();

	int n;

	cout << "\n\npress \"1\" to show the vectors  \n\n";
	cin >> n;
	if (n == 1)
	{
		show_vector();
	}

}

comparison::~comparison()  // destructor
{
	delete[]vfile1;
	delete[]vfile2;

}


